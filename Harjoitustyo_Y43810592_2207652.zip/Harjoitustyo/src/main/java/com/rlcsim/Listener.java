package com.rlcsim;

public interface Listener {

    public void update(String command);

}
